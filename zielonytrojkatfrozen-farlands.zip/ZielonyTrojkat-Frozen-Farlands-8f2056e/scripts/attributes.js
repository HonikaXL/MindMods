Attribute.add("ice");
Attribute.add("bauxite");
const timeStopMultiplier = 0.0001
const debugMode = false

module.exports = {
    timeStopMultiplier: timeStopMultiplier,
    debugMode: debugMode,
}

# schems
Пак схем для игры mindustry \
Discord: fox1va_

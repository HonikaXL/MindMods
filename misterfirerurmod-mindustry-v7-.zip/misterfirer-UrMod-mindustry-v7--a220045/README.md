# UrMod-mindustry-v7-


![logo](https://github.com/misterfirer/UrMod-mindustry-v7-/assets/75091040/ff4265d2-4c7f-4ad9-82cd-cc555b1c0aa1)




This mod adds tons of items and a new planet!!! The planet contains a poisonous atmosphere, but at the same time it has precious green material. The planet also contains the poisonous substance Puplenite.

![icon](https://github.com/misterfirer/UrMod-mindustry-v7-/assets/75091040/cb6b1876-3426-4778-b166-b13d143e7579)

(EN)
Hello! This mod was developed by me - SausageCheck. The mod is currently in beta. So far, the mod adds to the game: a new planet, 2 new units, 3 turrets, 1 drill, 2 blocks, 3 factories, etc. There are only 1 sector on the planet, but in the future there will be as many as 24! The planet itself represents a toxic green atmosphere and belief, and purple acid that eventually eats away units. Therefore, wait for new updates of my mod for some time ;).

(UA)
Привіт! Цей мод розроблений мною - SausageCheck. Наразі мод знаходиться в бета-версії. Поки що мод додає в гру: нову планету, 2 нових юніти, 3 вежі, 1 дриль, 2 блоки, 3 фабрики і т.д. На планеті всього 1 сектор, але в майбутньому їх буде стільки аж 24! Сама планета представляє токсичну зелену
атмосферу та вітер, а також фіолетову кислоту, яка з часом з’їдає одиниць. Тому чекайте нових оновлень мого моду деякий час ;).

![Grab-full](https://github.com/misterfirer/UrMod-mindustry-v7-/assets/75091040/afcc6928-f866-4274-8633-0e9653d7ab08)









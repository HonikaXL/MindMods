require("lib")
print(">>>>>MultiCrafter JavaScript loaded.")

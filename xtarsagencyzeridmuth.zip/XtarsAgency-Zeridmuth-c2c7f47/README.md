![icon](https://github.com/XtarsAgency/Zeridmuth/blob/main/icon.png)
# Zeridmuth
Hi There, this is a mindustry mod fully made on android. Yes, this is one of those rare occasions.
Our Discord Server(https://discord.com/invite/KuV5r39cpY)

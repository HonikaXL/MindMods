just adds random stuff to the erekir planet

Me on discord: 
- inxie_ratzey (MacBook account)
- fake_inxie_ratzey (Phone account)

Sector progression:

= Pre-tungsten =
- hallway
- presence
- passing (post-lake)

Holy Light (Beacons-yay) ~ By zinq and Archaeon and also a little bit of SemicolonNolan

A mod that aims add a bunch of weapons and content.
## Software Used
- **Visual Studio Code** : Editing all the files
- **Piskel** : Making sprites

---

## Mods that helped make this mod:

z0mbiesrock's Diamond Ore Mod (complex units and structures)

Eschatologue's Heavy Armaments Industries Mod (general modding startup)

Thank you so much! I'll give 90% of the credit to both those mods for helping me even start modding!

---

## Discord server: 

https://discord.gg/fwQc9J4DTM

---

I hope you enjoy! 


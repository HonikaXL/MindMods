require("units/units")
//Items
new Item("bullet");
new Item("nuke");
new Item("uranium");
new Item("quartz");
new Item("zinq");
new Item("zinq-good");
new Item("radicite");
new Liquid("jungle-juice");
// Blocks
require("blocks/zinc-wall")
require("blocks/ammo")

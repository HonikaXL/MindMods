# Flarogus
A sussy mod for Mindustry by BalaM314.

![Flarogus image](sprites/units/flarogus.png)

Adds the flarogus unit to Mindustry.

(If you want a mod that just changes the flare's texture, see [Flarogus Texture](https://github.com/BalaM314/flarogus-texture))

May or may not be balanced.
